Particle System Library by vitellary#1950

a library containing ParticleEmitter and ParticleAbsorber objects!
can be used to continuously spawn particle sprites that move in very customizable ways
detailed comments on how to use them can be found in the object files for the ParticleEmitter and ParticleAbsorber